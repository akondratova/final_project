import sqlalchemy
from sqlalchemy import orm
from data import db_session
from .db_session import SqlAlchemyBase


class InfoRussia(SqlAlchemyBase):
    __tablename__ = 'infoRussia'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    city = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    illpeople = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)

class InfoWorld(SqlAlchemyBase):
    __tablename__ = 'infoWorld'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    country = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    illpeople = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)